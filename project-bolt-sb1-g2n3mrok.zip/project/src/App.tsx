import React, { useState, useEffect } from 'react';
import { ThemeToggle } from './components/ThemeToggle';
import { ExpenseForm } from './components/ExpenseForm';
import { ExpenseList } from './components/ExpenseList';
import { ExpenseStats } from './components/ExpenseStats';
import { Expense, ThemeMode } from './types';
import { Wallet } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { getExpenses, saveExpense, deleteExpense } from './lib/storage';

function App() {
  const [theme, setTheme] = useState<ThemeMode>('light');
  const [expenses, setExpenses] = useState<Expense[]>([]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  useEffect(() => {
    const storedExpenses = getExpenses();
    setExpenses(storedExpenses);
  }, []);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleAddExpense = (newExpense: { description: string; amount: number; category: string }) => {
    const expense: Expense = {
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      ...newExpense,
    };

    saveExpense(expense);
    setExpenses((prev) => [expense, ...prev]);
  };

  const handleDeleteExpense = (id: string) => {
    deleteExpense(id);
    setExpenses((prev) => prev.filter((expense) => expense.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Toaster position="top-right" />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <header className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <Wallet className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Expense Tracker</h1>
          </div>
          <div className="flex items-center gap-4">
            <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
          </div>
        </header>

        <main className="space-y-8">
          <ExpenseStats expenses={expenses} />
          
          <div className="grid md:grid-cols-[400px,1fr] gap-8">
            <div className="md:sticky md:top-8 h-fit">
              <ExpenseForm onAddExpense={handleAddExpense} />
            </div>
            
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Recent Expenses</h2>
              <ExpenseList expenses={expenses} onDeleteExpense={handleDeleteExpense} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;