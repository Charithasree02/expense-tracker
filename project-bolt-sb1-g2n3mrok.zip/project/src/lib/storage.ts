import { Expense } from '../types';

const EXPENSES_KEY = 'expense_tracker_expenses';

export const getExpenses = (): Expense[] => {
  const expenses = localStorage.getItem(EXPENSES_KEY);
  return expenses ? JSON.parse(expenses) : [];
};

export const saveExpense = (expense: Expense): void => {
  const expenses = getExpenses();
  expenses.unshift(expense);
  localStorage.setItem(EXPENSES_KEY, JSON.stringify(expenses));
};

export const deleteExpense = (expenseId: string): void => {
  const expenses = getExpenses();
  const updatedExpenses = expenses.filter((e: Expense) => e.id !== expenseId);
  localStorage.setItem(EXPENSES_KEY, JSON.stringify(updatedExpenses));
};