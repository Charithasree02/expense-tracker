import React from 'react';
import { LogOut, User } from 'lucide-react';
import toast from 'react-hot-toast';
import { setCurrentUser } from '../lib/storage';

interface UserMenuProps {
  email: string;
  onSignOut: () => void;
}

export function UserMenu({ email, onSignOut }: UserMenuProps) {
  const handleSignOut = () => {
    setCurrentUser(null);
    onSignOut();
    toast.success('Signed out successfully');
  };

  return (
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-2">
        <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900">
          <User className="w-5 h-5 text-blue-600 dark:text-blue-300" />
        </div>
        <span className="text-sm text-gray-700 dark:text-gray-300">{email}</span>
      </div>
      <button
        onClick={handleSignOut}
        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-600 dark:text-gray-400 transition-colors"
        aria-label="Sign out"
      >
        <LogOut className="w-5 h-5" />
      </button>
    </div>
  );
}