import React from 'react';
import { Trash2 } from 'lucide-react';
import { Expense } from '../types';

interface ExpenseListProps {
  expenses: Expense[];
  onDeleteExpense: (id: string) => void;
}

export function ExpenseList({ expenses, onDeleteExpense }: ExpenseListProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatAmount = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      food: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      transportation: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      entertainment: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      utilities: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      shopping: 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      general: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200',
    };
    return colors[category.toLowerCase()] || colors.general;
  };

  return (
    <div className="space-y-4">
      {expenses.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          No expenses recorded yet. Start by adding one!
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {expenses.map((expense) => (
            <div
              key={expense.id}
              className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100">{expense.description}</h3>
                  <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{formatAmount(expense.amount)}</p>
                </div>
                <button
                  onClick={() => onDeleteExpense(expense.id)}
                  className="text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors"
                  aria-label="Delete expense"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
              <div className="flex justify-between items-center mt-4">
                <span className={`px-2 py-1 rounded-full text-sm ${getCategoryColor(expense.category)}`}>
                  {expense.category}
                </span>
                <span className="text-sm text-gray-500 dark:text-gray-400">{formatDate(expense.date)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}